# RASDrummingPaper
Robotics and Autonomous Systems - Paper.
