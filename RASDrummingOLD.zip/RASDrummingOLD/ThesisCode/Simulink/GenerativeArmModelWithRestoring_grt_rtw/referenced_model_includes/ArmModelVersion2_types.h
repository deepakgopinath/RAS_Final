/*
 * ArmModelVersion2_types.h
 *
 * Code generation for model "ArmModelVersion2".
 *
 * Model version              : 1.91
 * Simulink Coder version : 8.5 (R2013b) 08-Aug-2013
 * C source code generated on : Mon Mar 16 10:19:01 2015
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */
#ifndef RTW_HEADER_ArmModelVersion2_types_h_
#define RTW_HEADER_ArmModelVersion2_types_h_

/* Forward declaration for rtModel */
typedef struct tag_RTM_ArmModelVersion2_T RT_MODEL_ArmModelVersion2_T;

#endif                                 /* RTW_HEADER_ArmModelVersion2_types_h_ */
