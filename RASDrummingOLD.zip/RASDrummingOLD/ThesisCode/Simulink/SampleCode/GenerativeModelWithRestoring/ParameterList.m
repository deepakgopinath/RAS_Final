%pulse - 189, 0.5, 5 0.01, %initial vel = -3, 0.86 -COR
%pulse - 300, 0.3, 5, 0.01, initial vel = 0, 0.86 COR
%pulse - 200, 0.5, 5, 0.01, initial vel = 0, 0.86 COR
%pulse 189, 0.5, 5, 0,  initial vel = -1.2/s, 0.86 (Picture1)


%Evaluation Profile List

%NoGravity
    %initial vel = 0;
        %initial pos = 0;
        %initial pos = 0.2;
        %initial pos = 0.1;
        %initial pos = -0.1;
        %initial pos = -0.2;
%LowTohigh
    %initial vel = 0;
        %initial pos = 0;
        %initial pos = 0.2;
        %initial pos = 0.1;
        %initial pos = -0.1;
        %initial pos = -0.2;
%HighToLow
    %initial vel = 0
        %intial pos = 0.2;
        %intial pos = 0.1;
        %intial pos = 0 ;
        %initial pos = -0.1
        %intial pos = -0.2
