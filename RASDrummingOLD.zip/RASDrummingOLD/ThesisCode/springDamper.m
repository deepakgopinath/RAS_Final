m = 0.0001;
c = 10;
k = 0.05;

num = [0 0 1];
den = [m c k];

step(num,den);